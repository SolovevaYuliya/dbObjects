﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Building;

public partial class BuildsSolovevaContext : DbContext
{
    public BuildsSolovevaContext()
    {
    }

    public BuildsSolovevaContext(DbContextOptions<BuildsSolovevaContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Build> Builds { get; set; }

    public virtual DbSet<Itog> Itogs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlite("Data Source=C:\\Users\\студент\\Desktop\\Builds_Soloveva.db");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Build>(entity =>
        {
            entity.HasKey(e => e.IdBuild);

            entity.HasIndex(e => e.IdBuild, "IX_Builds_id_build").IsUnique();

            entity.Property(e => e.IdBuild)
                .ValueGeneratedNever()
                .HasColumnName("id_build");
            entity.Property(e => e.TypeBuild).HasColumnName("Type_Build");
        });

        modelBuilder.Entity<Itog>(entity =>
        {
            entity.ToTable("Itog");

            entity.HasIndex(e => e.Id, "IX_Itog_id").IsUnique();

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.CountRooms).HasColumnName("Count_Rooms");

            entity.HasOne(d => d.BuildNavigation).WithMany(p => p.Itogs)
                .HasForeignKey(d => d.Build)
                .OnDelete(DeleteBehavior.ClientSetNull);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
